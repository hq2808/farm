package com.farmconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
